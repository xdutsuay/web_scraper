#ifndef SCRAPER_H
#define SCRAPER_H

void scrape_url(const char *url, char **keywords, int keyword_count);

#endif // SCRAPER_H

