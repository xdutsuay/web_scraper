#ifndef UTILS_H
#define UTILS_H

int read_config_file(const char *filename, char ***urls, int *url_count, char ***keywords, int *keyword_count);

#endif // UTILS_H

